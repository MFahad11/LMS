import Routing from "./layouts/Routes/Routing";

export default function App() {
  return (
    <>
  <Routing/>
    </>
  );
}


